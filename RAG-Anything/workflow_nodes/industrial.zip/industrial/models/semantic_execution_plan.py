"""语义运行时计划（SemTK IR 思想对齐：DAG + 对象 + 约束链）。"""

from __future__ import annotations

import uuid

from pydantic import BaseModel, ConfigDict, Field


class SemanticDependency(BaseModel):
    model_config = ConfigDict(extra="ignore")

    subject: str
    predicate: str
    obj: str


class SemanticExecutionPlan(BaseModel):
    model_config = ConfigDict(extra="ignore")

    plan_id: str = Field(default_factory=lambda: uuid.uuid4().hex)
    workflow_node_order: list[str] = Field(default_factory=list)
    ontology_object_ids: list[str] = Field(default_factory=list)
    semantic_dependencies: list[SemanticDependency] = Field(default_factory=list)
    constraint_chain_refs: list[str] = Field(default_factory=list)
    execution_order: list[str] = Field(
        default_factory=list,
        description="工业动作/工艺的线性序建议（拓扑后处理）",
    )
    runtime_legality_notes: list[str] = Field(default_factory=list)
    state_ordering_hints: list[str] = Field(default_factory=list)
