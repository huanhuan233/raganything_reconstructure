"""工艺状态变迁定义（供 ``state.transition.validate`` 使用）。"""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field


class StateTransitionDefinition(BaseModel):
    model_config = ConfigDict(extra="ignore")

    from_state: str
    to_state: str
    label: str = ""
    required_dependencies: list[str] = Field(
        default_factory=list,
        description="进入 to_state 前必须在轨迹中出现的低层状态标识",
    )


class TransitionPolicy(BaseModel):
    """运行时策略：黑名单边 +（可选）显式必选序。"""

    model_config = ConfigDict(extra="ignore")

    forbidden_edges: list[tuple[str, str]] = Field(default_factory=list)
    required_order: list[tuple[str, str]] = Field(
        default_factory=list,
        description="(before_label, after_label)",
    )
