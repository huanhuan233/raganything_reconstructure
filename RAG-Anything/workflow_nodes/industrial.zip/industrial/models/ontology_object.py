"""标准化工业本体对象（Runtime-first / 非 RDF）。"""

from __future__ import annotations

from enum import Enum

from pydantic import BaseModel, ConfigDict, Field


class OntologyObjectType(str, Enum):
    PART = "Part"
    PROCESS = "Process"
    EQUIPMENT = "Equipment"
    OPERATION = "Operation"
    MATERIAL = "Material"
    CONSTRAINT = "Constraint"
    STATE = "State"
    RULE = "Rule"


class OntologyObject(BaseModel):
    model_config = ConfigDict(extra="ignore")

    object_id: str = Field(description="运行时稳定 id")
    ontology_type: OntologyObjectType
    label: str = ""
    synonyms: list[str] = Field(default_factory=list)
    attributes: dict[str, str | float | int | bool] = Field(default_factory=dict)
    source_refs: list[str] = Field(default_factory=list, description="chunk/table id 溯源")
