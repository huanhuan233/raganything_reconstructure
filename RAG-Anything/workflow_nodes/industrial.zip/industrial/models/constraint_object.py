"""工业约束对象：供 Runtime Filter / Graph 挂载。"""

from __future__ import annotations

from enum import Enum

from pydantic import BaseModel, ConfigDict, Field


class ConstraintKind(str, Enum):
    MUST = "must"
    MUST_NOT = "must_not"
    BEFORE = "before"
    AFTER = "after"
    DEPENDS_ON = "depends_on"
    TEMPERATURE_LIMIT = "temperature_limit"
    THICKNESS_LIMIT = "thickness_limit"
    MATERIAL_LIMIT = "material_limit"
    FORBID_PAIR = "forbid_pair"


class AppliesTo(BaseModel):
    model_config = ConfigDict(extra="ignore")

    ontology_type: str | None = None


class PredicatePayload(BaseModel):
    """可扩展 KV；``RuntimeConstraintEngine`` 识别 numeric_threshold / forbid_pair / text 等。"""

    model_config = ConfigDict(extra="allow")

    text: str | None = None
    relation: str | None = None
    forbidden_target_kind: str | None = None

    prop_key: str | None = Field(default=None, description="attributes 上的字段名")

    material_a: str | None = None
    process_b: str | None = None
    op: str | None = None
    value: float | None = None
    temperature_c_max: float | None = None
    thickness_mm_min: float | None = None
    requires_ordering_before: str | None = None


class ConstraintObject(BaseModel):
    model_config = ConfigDict(extra="ignore")

    constraint_id: str
    kind: ConstraintKind
    predicates: PredicatePayload = Field(default_factory=PredicatePayload)
    applies_to: AppliesTo = Field(default_factory=AppliesTo)
    nl_source: str = Field(default="", description="原文片段溯源")
    confidence: float = Field(default=1.0, ge=0.0, le=1.0)
