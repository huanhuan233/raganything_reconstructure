"""Higher-level Rule 表面结构（占位，可向 Rule Runtime 演进）。"""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field


class RuntimeRule(BaseModel):
    model_config = ConfigDict(extra="ignore")

    rule_id: str
    triggers: list[str] = Field(default_factory=list)
    explanations: list[str] = Field(default_factory=list)
    binds_constraint_ids: list[str] = Field(default_factory=list)
