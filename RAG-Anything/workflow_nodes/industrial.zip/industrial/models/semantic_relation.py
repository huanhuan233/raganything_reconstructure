"""Neo4j 对齐的语义关系边（运行时 IR，不含 RDF）。"""

from __future__ import annotations

from enum import Enum

from pydantic import BaseModel, ConfigDict, Field


class IndustrialRelation(str, Enum):
    USES = "USES"
    CONSTRAINED_BY = "CONSTRAINED_BY"
    REQUIRES = "REQUIRES"
    TRANSITIONS_TO = "TRANSITIONS_TO"
    FORBIDS = "FORBIDS"
    DEPENDS_ON = "DEPENDS_ON"


class SemanticRelation(BaseModel):
    model_config = ConfigDict(extra="ignore")

    subject_id: str
    predicate: IndustrialRelation
    object_id: str
    evidence: list[str] = Field(default_factory=list)
