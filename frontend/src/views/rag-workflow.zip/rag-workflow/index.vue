<script setup lang="ts">
import type { ViewportTransform, VueFlowStore } from '@vue-flow/core';
import { nextTick, onMounted, ref, unref } from 'vue';
import type { RagWorkflowStoredDocument } from '@/types/ragWorkflow';
import WorkflowCanvas from './components/WorkflowCanvas.vue';
import WorkflowHeader from './components/WorkflowHeader.vue';
import WorkflowJsonPanel from './components/WorkflowJsonPanel.vue';
import WorkflowLoadDialog from './components/WorkflowLoadDialog.vue';
import NodePalette from './components/NodePalette.vue';
import NodeConfigPanel from './components/NodeConfigPanel.vue';
import WorkflowRunRecords from './components/WorkflowRunRecords.vue';
import WorkflowRunResult from './components/WorkflowRunResult.vue';
import WorkflowToolbar from './components/WorkflowToolbar.vue';
import { useNodeConfig } from './composables/useNodeConfig';
import { useWorkflowNodes } from './composables/useWorkflowNodes';
import { useWorkflowRun } from './composables/useWorkflowRun';
import { useWorkflowRunRecords } from './composables/useWorkflowRunRecords';
import { useWorkflowStore } from './composables/useWorkflowStore';
import { useWorkflowState } from './composables/useWorkflowState';
import { flowToRunPayload, parseStoredWorkflowDocument } from './utils/workflowTransform';

const canvasWrapRef = ref<HTMLElement | null>(null);

const {
  flowNodes,
  flowEdges,
  selectedNodeId,
  workflowId,
  workflowDisplayName,
  workflowDescription,
  workflowInputJson,
  vfStore,
  zoomPercent,
  workflowPreview,
  onStructureChange,
  updateWorkflowPreview
} = useWorkflowState();

const nodePickerVisible = ref(false);
const nodePickerPos = ref({ x: 56, y: 56 });
const filterRunsByCurrentWorkflow = ref(true);

const {
  runHistoryList,
  runHistoryLoading,
  runDetailVisible,
  runDetailLoading,
  runDetailFull,
  prettyJson,
  refreshRunHistory,
  openRunDetail,
  deleteRunRecord
} = useWorkflowRunRecords({
  workflowId,
  filterByCurrentWorkflow: filterRunsByCurrentWorkflow
});

const {
  runLoading,
  lastRunRaw,
  runErrorMsg,
  runStatus,
  runWorkflow,
  runAnswerSnippet
} = useWorkflowRun({
  refreshRunHistory
});

const {
  paletteCatalog,
  paletteLoading,
  fetchNodeTypes,
  addNodeFromMeta,
  connectNodes
} = useWorkflowNodes({
  flowNodes,
  flowEdges,
  onStructureChange,
  closeNodePicker: () => {
    nodePickerVisible.value = false;
  }
});

const {
  labelDraft,
  configDraft,
  selectedNode,
  selectedNodeMeta,
  hasConfigSchema,
  localSchemaConfig,
  patchSchemaField,
  applyConfigDraftNow,
  onNodeSelected,
  clearSelectionDrafts,
  resetDraftsAfterClearCanvas
} = useNodeConfig({
  flowNodes,
  selectedNodeId,
  paletteCatalog,
  onStructureChange
});

function applyLoadedDocument(doc: RagWorkflowStoredDocument) {
  const parsed = parseStoredWorkflowDocument(doc, paletteCatalog.value);
  workflowId.value = parsed.workflowId;
  workflowDisplayName.value = parsed.workflowDisplayName;
  workflowDescription.value = parsed.workflowDescription;
  workflowInputJson.value = parsed.inputJsonText;
  flowNodes.value = parsed.flowNodes;
  flowEdges.value = parsed.flowEdges;
  selectedNodeId.value = null;
  clearSelectionDrafts();
  resetDraftsAfterClearCanvas();
  nextTick(() => {
    onStructureChange();
    nextTick(() => fitViewSafe());
  });
}

const {
  saveLoading,
  loadDialogVisible,
  loadListLoading,
  savedWorkflowList,
  saveWorkflow,
  listSavedWorkflows,
  openLoadDialog,
  loadWorkflowByIdent,
  deleteSavedWorkflowCurrent
} = useWorkflowStore({
  flowNodes,
  flowEdges,
  workflowId,
  workflowDisplayName,
  workflowDescription,
  workflowInputJson,
  applyLoadedDocument
});

function openNodePicker(anchor?: HTMLElement | null) {
  nodePickerVisible.value = true;
  if (anchor) {
    const r = anchor.getBoundingClientRect();
    const wrap = canvasWrapRef.value?.getBoundingClientRect();
    if (wrap) {
      nodePickerPos.value = {
        x: r.left - wrap.left + r.width + 8,
        y: r.top - wrap.top
      };
    }
  } else {
    nodePickerPos.value = { x: 56, y: 56 };
  }
}

function onVfInit(store: VueFlowStore) {
  vfStore.value = store;
  zoomPercent.value = Math.round(unref(store.viewport).zoom * 100);
}

function onViewportChange(vp: ViewportTransform) {
  zoomPercent.value = Math.round(vp.zoom * 100);
}

function fitViewSafe() {
  vfStore.value?.fitView({ padding: 0.2, duration: 200 });
}

function resetViewport() {
  vfStore.value?.setViewport({ x: 0, y: 0, zoom: 1 }, { duration: 200 });
}

function zoomStep(delta: number) {
  const vf = vfStore.value;
  if (!vf) return;
  const z = unref(vf.viewport).zoom ?? 1;
  const next = Math.min(1.8, Math.max(0.4, z + delta));
  vf.zoomTo(next, { duration: 150 });
}

function onPaneClickOuter() {
  nodePickerVisible.value = false;
  selectedNodeId.value = null;
  clearSelectionDrafts();
}

function clearCanvas() {
  flowNodes.value = [];
  flowEdges.value = [];
  selectedNodeId.value = null;
  clearSelectionDrafts();
  resetDraftsAfterClearCanvas();
  onStructureChange();
}

function closeNodeConfigDrawer() {
  selectedNodeId.value = null;
  clearSelectionDrafts();
}

async function handleRunWorkflow() {
  await runWorkflow(
    flowToRunPayload(flowNodes.value, flowEdges.value, workflowId.value.trim(), workflowInputJson.value),
    workflowInputJson.value
  );
}

function moreHintHotkeys() {
  window.$message?.info('Delete / Backspace：删除选中节点或边；拖拽连线：连接节点');
}

onMounted(() => {
  void fetchNodeTypes();
  updateWorkflowPreview();
  void refreshRunHistory();
});
</script>

<template>
  <div class="rag-wf-page min-h-0 min-w-0 h-full w-full flex-1 overflow-hidden">
    <WorkflowHeader
      v-model:workflow-id="workflowId"
      v-model:workflow-name="workflowDisplayName"
      v-model:description="workflowDescription"
      :save-loading="saveLoading"
      :load-list-loading="loadListLoading"
      :palette-loading="paletteLoading"
      :run-loading="runLoading"
      @save="saveWorkflow"
      @open-load="openLoadDialog"
      @delete-workflow="deleteSavedWorkflowCurrent"
      @refresh-palette="fetchNodeTypes"
      @clear-canvas="clearCanvas"
      @run="handleRunWorkflow"
    />

    <div class="rag-wf-body">
      <WorkflowToolbar
        @open-picker="anchor => openNodePicker(anchor)"
        @fit-view="fitViewSafe"
        @reset-view="resetViewport"
        @hotkeys="moreHintHotkeys"
      />

      <main ref="canvasWrapRef" class="rag-wf-canvas-wrap" @click.self="onPaneClickOuter">
        <WorkflowCanvas
          v-model:nodes="flowNodes"
          v-model:edges="flowEdges"
          @init="onVfInit"
          @viewport-change="onViewportChange"
          @node-click="onNodeSelected"
          @pane-click="onPaneClickOuter"
          @connect="connectNodes"
          @structure-change="onStructureChange"
        />
        <NodePalette
          :visible="nodePickerVisible"
          :position="nodePickerPos"
          :loading="paletteLoading"
          :catalog="paletteCatalog"
          @close="nodePickerVisible = false"
          @add-node="addNodeFromMeta"
        />

        <div class="rag-wf-canvas-floating-stats">
          <div class="rag-wf-canvas-floating-inner">
            <div class="rag-wf-footer-left">
              <span>节点 {{ flowNodes.length }}</span>
              <span class="rag-wf-footer-sep">·</span>
              <span>边 {{ flowEdges.length }}</span>
            </div>
            <div class="rag-wf-footer-center">
              <button type="button" class="rag-wf-zoom-btn" @click="zoomStep(-0.1)">−</button>
              <span class="rag-wf-zoom-val">{{ zoomPercent }}%</span>
              <button type="button" class="rag-wf-zoom-btn" @click="zoomStep(0.1)">+</button>
            </div>
            <div class="rag-wf-footer-right">
              <template v-if="runStatus === 'running'">运行中…</template>
              <template v-else-if="runStatus === 'success'">上次运行：成功</template>
              <template v-else-if="runStatus === 'error'">上次运行：失败</template>
              <template v-else>就绪</template>
            </div>
          </div>
        </div>
      </main>

      <aside class="rag-wf-context-col">
        <ElCollapse class="rag-wf-collapse rag-wf-collapse--context">
          <WorkflowJsonPanel v-model:workflow-preview="workflowPreview" v-model:input-data-json="workflowInputJson" />
          <WorkflowRunResult
            :last-run-raw="lastRunRaw"
            :run-error-msg="runErrorMsg"
            :run-status="runStatus"
            :answer-snippet="runAnswerSnippet(lastRunRaw)"
          />
          <WorkflowRunRecords
            v-model:filter-runs-by-current-workflow="filterRunsByCurrentWorkflow"
            v-model:run-detail-visible="runDetailVisible"
            :run-history-list="runHistoryList"
            :run-history-loading="runHistoryLoading"
            :run-detail-loading="runDetailLoading"
            :run-detail-full="runDetailFull"
            :pretty-json="prettyJson"
            @refresh-list="refreshRunHistory"
            @open-detail="openRunDetail"
            @delete-record="deleteRunRecord"
          />
        </ElCollapse>
      </aside>
    </div>

    <ElDrawer
      :model-value="selectedNodeId != null"
      class="rag-wf-node-config-drawer"
      direction="rtl"
      size="380px"
      append-to-body
      :close-on-click-modal="true"
      @update:model-value="v => !v && closeNodeConfigDrawer()"
    >
      <template #header>
        <div class="rag-wf-drawer-head">
          <span class="rag-wf-drawer-title">节点配置</span>
          <span v-if="selectedNode" class="rag-wf-drawer-sub">{{ String(selectedNode.id) }}</span>
        </div>
      </template>
      <NodeConfigPanel
        v-if="selectedNode"
        v-model:label-draft="labelDraft"
        v-model:config-draft="configDraft"
        :selected-node="selectedNode"
        :selected-node-meta="selectedNodeMeta"
        :has-config-schema="hasConfigSchema"
        :local-schema-config="localSchemaConfig"
        @patch-field="patchSchemaField"
        @apply-json-config="applyConfigDraftNow"
      />
    </ElDrawer>

    <WorkflowLoadDialog
      v-model:visible="loadDialogVisible"
      :saved-workflow-list="savedWorkflowList"
      :load-list-loading="loadListLoading"
      @refresh="listSavedWorkflows"
      @load="loadWorkflowByIdent"
    />
  </div>
</template>

<style lang="scss">
@import './styles/index.scss';
</style>
