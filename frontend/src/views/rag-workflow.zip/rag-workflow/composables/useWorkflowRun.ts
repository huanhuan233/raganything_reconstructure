import type { AxiosError } from 'axios';
import { ref } from 'vue';
import { fetchRagWorkflowRun } from '@/service/api';
import type { RagWorkflowRunPayload, RagWorkflowRunResult } from '@/types/ragWorkflow';
import { formatFastApiDetail } from '../utils/apiError';
import { stringifyPretty } from '../utils/jsonHelper';
import { safeParseJson5 } from '../utils/jsonHelper';

export type RunStatus = 'idle' | 'running' | 'success' | 'error';

export function useWorkflowRun(options: {
  refreshRunHistory: () => Promise<void>;
}) {
  const { refreshRunHistory } = options;

  const runLoading = ref(false);
  const lastRunRaw = ref('');
  const runErrorMsg = ref('');
  const runStatus = ref<RunStatus>('idle');

  function formatRun(res: RagWorkflowRunResult): string {
    return stringifyPretty(res);
  }

  async function runWorkflow(payload: RagWorkflowRunPayload, inputJsonText: string): Promise<boolean> {
    runErrorMsg.value = '';
    const rawIn = inputJsonText.trim();
    if (rawIn && safeParseJson5(inputJsonText) === null) {
      runErrorMsg.value = '入口 input_data JSON 解析失败';
      runStatus.value = 'error';
      window.$message?.error(runErrorMsg.value);
      return false;
    }

    runLoading.value = true;
    lastRunRaw.value = '';
    runStatus.value = 'running';

    try {
      const res = await fetchRagWorkflowRun(payload);
      lastRunRaw.value = formatRun(res);
      runStatus.value = res.success ? 'success' : 'error';
      return true;
    } catch (e) {
      const ax = e as AxiosError<{ detail?: unknown }>;
      runErrorMsg.value = formatFastApiDetail(ax.response?.data?.detail) || ax.message || String(e);
      runStatus.value = 'error';
      window.$message?.error(runErrorMsg.value);
      lastRunRaw.value = '';
      return false;
    } finally {
      runLoading.value = false;
      await refreshRunHistory();
    }
  }

  /** 根据 ``API`` 扁平结果中提取便于展示的 answer 摘要 */
  function runAnswerSnippet(rawJson: string): string {
    if (!rawJson.trim()) return '';
    try {
      const o = JSON.parse(rawJson) as Record<string, unknown>;
      const nr = o.node_results as Record<string, { data?: { answer?: string } }> | undefined;
      if (!nr) return '';
      for (const v of Object.values(nr)) {
        const a = v?.data?.answer;
        if (typeof a === 'string' && a.trim()) return a.trim().slice(0, 480);
      }
      return '';
    } catch {
      return '';
    }
  }

  return {
    runLoading,
    lastRunRaw,
    runErrorMsg,
    runStatus,
    runWorkflow,
    formatRun,
    runAnswerSnippet
  };
}
