import type { Connection, Edge, Node } from '@vue-flow/core';
import { addEdge } from '@vue-flow/core';
import { ref, type Ref } from 'vue';
import { nanoid } from '@sa/utils';
import { fetchRagNodeTypes } from '@/service/api';
import type { RagFlowNodeData, RagNodeMetadata } from '@/types/ragWorkflow';

export function useWorkflowNodes(options: {
  flowNodes: Ref<Node[]>;
  flowEdges: Ref<Edge[]>;
  onStructureChange: () => void;
  closeNodePicker?: () => void;
}) {
  const { flowNodes, flowEdges, onStructureChange, closeNodePicker } = options;

  const paletteCatalog = ref<RagNodeMetadata[]>([]);
  const paletteLoading = ref(false);
  let spawnOffset = 0;

  async function fetchNodeTypes() {
    paletteLoading.value = true;
    try {
      const res = await fetchRagNodeTypes();
      paletteCatalog.value = [...res.nodes];
    } finally {
      paletteLoading.value = false;
    }
  }

  function addNodeFromMeta(meta: RagNodeMetadata) {
    const id = `wf_${nanoid(8)}`;
    spawnOffset += 1;
    const x = 80 + ((spawnOffset * 88) % 520);
    const y = 80 + ((spawnOffset * 64) % 360);

    const data: RagFlowNodeData = {
      label: meta.display_name,
      nodeType: meta.node_type,
      config: {}
    };

    const vfNode: Node = {
      id,
      type: 'default',
      position: { x, y },
      draggable: true,
      connectable: true,
      selectable: true,
      label: data.label,
      data
    };

    flowNodes.value = [...(flowNodes.value as Node[]), vfNode];
    closeNodePicker?.();
    onStructureChange();
  }

  function connectNodes(c: Connection) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    flowEdges.value = addEdge(c, flowEdges.value as any) as Edge[];
    onStructureChange();
  }

  return {
    paletteCatalog,
    paletteLoading,
    fetchNodeTypes,
    addNodeFromMeta,
    connectNodes
  };
}
