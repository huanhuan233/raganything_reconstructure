<script setup lang="ts">
const workflowPreview = defineModel<string>('workflowPreview', { required: true });
const inputDataJson = defineModel<string>('inputDataJson', { required: true });
</script>

<template>
  <ElCollapseItem title="Workflow JSON（实时）" name="json">
    <div class="rag-wf-field">
      <div class="rag-wf-field-label">提交载荷预览（workflow_id / nodes / edges / entry / input）</div>
      <ElScrollbar max-height="120px">
        <pre class="rag-wf-json-pre">{{ workflowPreview }}</pre>
      </ElScrollbar>
    </div>
    <div class="rag-wf-field">
      <div class="rag-wf-field-label">入口 input_data（JSON）</div>
      <ElInput v-model="inputDataJson" type="textarea" :autosize="{ minRows: 5, maxRows: 10 }" class="font-mono" spellcheck="false" />
    </div>
  </ElCollapseItem>
</template>
