<script setup lang="ts">
const workflowId = defineModel<string>('workflowId', { required: true });
const workflowName = defineModel<string>('workflowName', { required: true });
const description = defineModel<string>('description', { required: true });

defineProps<{
  saveLoading: boolean;
  loadListLoading: boolean;
  paletteLoading: boolean;
  runLoading: boolean;
}>();

const emit = defineEmits<{
  save: [];
  'open-load': [];
  'delete-workflow': [];
  'refresh-palette': [];
  'clear-canvas': [];
  run: [];
}>();
</script>

<template>
  <header class="rag-wf-header">
    <div class="rag-wf-header-left">
      <span class="rag-wf-title">多模态RAG工作流</span>
      <span class="rag-wf-badge">编排</span>
    </div>
    <div class="rag-wf-header-center">
      <div class="rag-wf-header-fields">
        <ElInput v-model="workflowId" size="small" class="rag-wf-wid" placeholder="workflow_id（保存文件名）" clearable />
        <ElInput v-model="workflowName" size="small" class="rag-wf-name" placeholder="工作流名称" clearable />
        <ElInput v-model="description" size="small" class="rag-wf-desc" placeholder="描述（可选）" clearable />
      </div>
    </div>
    <div class="rag-wf-header-right">
      <ElButton size="small" type="success" plain :loading="saveLoading" @click="emit('save')">保存工作流</ElButton>
      <ElButton size="small" type="primary" plain :loading="loadListLoading" @click="emit('open-load')">加载工作流</ElButton>
      <ElButton size="small" type="danger" plain @click="emit('delete-workflow')">删除工作流</ElButton>
      <ElButton size="small" :loading="paletteLoading" @click="emit('refresh-palette')">刷新节点类型</ElButton>
      <ElButton size="small" type="danger" plain @click="emit('clear-canvas')">清空画布</ElButton>
      <ElButton size="small" type="primary" :loading="runLoading" @click="emit('run')">运行工作流</ElButton>
    </div>
  </header>
</template>
