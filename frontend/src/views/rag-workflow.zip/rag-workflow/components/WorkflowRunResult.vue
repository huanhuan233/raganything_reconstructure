<script setup lang="ts">
import type { RunStatus } from '../composables/useWorkflowRun';

defineProps<{
  lastRunRaw: string;
  runErrorMsg: string;
  runStatus: RunStatus;
  answerSnippet: string;
}>();
</script>

<template>
  <ElCollapseItem title="运行结果" name="run">
    <div v-if="runStatus === 'error' && runErrorMsg" class="rag-wf-field">
      <div class="rag-wf-field-label">请求错误</div>
      <pre class="rag-wf-json-pre">{{ runErrorMsg }}</pre>
    </div>
    <div v-if="answerSnippet && lastRunRaw" class="rag-wf-field">
      <div class="rag-wf-field-label">answer 摘要</div>
      <pre class="rag-wf-json-pre">{{ answerSnippet }}</pre>
    </div>
    <ElEmpty v-if="!lastRunRaw && runStatus !== 'error'" description="尚未运行" :image-size="56" />
    <template v-if="lastRunRaw">
      <div class="rag-wf-field-label">完整响应</div>
      <ElScrollbar max-height="120px">
        <pre class="rag-wf-json-pre">{{ lastRunRaw }}</pre>
      </ElScrollbar>
    </template>
  </ElCollapseItem>
</template>
