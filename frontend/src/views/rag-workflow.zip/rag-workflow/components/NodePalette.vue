<script setup lang="ts">
import { computed, ref } from 'vue';
import type { RagNodeMetadata } from '@/types/ragWorkflow';
import { buildPaletteGroups } from '../utils/nodeCategory';

const props = defineProps<{
  visible: boolean;
  position: { x: number; y: number };
  loading: boolean;
  catalog: RagNodeMetadata[];
}>();

const emit = defineEmits<{
  close: [];
  'add-node': [meta: RagNodeMetadata];
}>();

const nodePickerSearch = ref('');

const filteredPickerGroups = computed(() => buildPaletteGroups(props.catalog, nodePickerSearch.value.trim()));
</script>

<template>
  <div
    v-show="visible"
    class="rag-wf-node-picker"
    :style="{ left: `${position.x}px`, top: `${position.y}px` }"
    @click.stop
  >
    <div class="rag-wf-np-head">
      <span class="rag-wf-np-title">节点库</span>
      <button type="button" class="rag-wf-np-close" title="关闭" @click="emit('close')">×</button>
    </div>
    <div class="rag-wf-np-search">
      <ElInput v-model="nodePickerSearch" size="small" placeholder="搜索节点类型" clearable />
    </div>
    <div class="rag-wf-np-scroll">
      <ElSkeleton v-if="loading && !catalog.length" :rows="5" animated />
      <template v-else>
        <template v-for="g in filteredPickerGroups" :key="g.key">
          <div class="rag-wf-np-group-title">{{ g.title }}</div>
          <button
            v-for="meta in g.items"
            :key="meta.node_type"
            type="button"
            class="rag-wf-np-item"
            @click="emit('add-node', meta)"
          >
            <div class="rag-wf-np-icon">
              <span class="rag-wf-np-badge">{{ meta.node_type.split('.')[0]?.slice(0, 2).toUpperCase() }}</span>
            </div>
            <div class="rag-wf-np-text">
              <div class="rag-wf-np-name">{{ meta.display_name }}</div>
              <div class="rag-wf-np-sub">{{ meta.node_type }}</div>
              <div v-if="meta.is_placeholder" class="rag-wf-np-tags">
                <span class="rag-wf-np-ph">占位</span>
              </div>
            </div>
          </button>
        </template>
        <ElEmpty v-if="!filteredPickerGroups.length" description="无匹配节点" :image-size="72" />
      </template>
    </div>
  </div>
</template>

<style scoped lang="scss">
.rag-wf-node-picker {
  position: absolute;
  width: 300px;
  height: min(420px, calc(100% - 24px));
  max-height: min(420px, calc(100% - 24px));
  box-sizing: border-box;
  background: #fff;
  border: 1px solid #e5e7eb;
  border-radius: 10px;
  box-shadow: 0 10px 30px rgb(0 0 0 / 12%);
  z-index: 30;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.rag-wf-np-head {
  flex-shrink: 0;
  display: flex;
  align-items: center;
  padding: 10px 12px;
  border-bottom: 1px solid #eef2f7;
}

.rag-wf-np-title {
  font-weight: 600;
  font-size: 14px;
  color: #111827;
}

.rag-wf-np-close {
  margin-left: auto;
  border: none;
  background: transparent;
  width: 28px;
  height: 28px;
  border-radius: 8px;
  cursor: pointer;
  color: #9ca3af;
  font-size: 18px;
  line-height: 1;
}

.rag-wf-np-close:hover {
  background: #f3f4f6;
  color: #374151;
}

.rag-wf-np-search {
  flex-shrink: 0;
  padding: 10px 12px;
  border-bottom: 1px solid #f3f4f6;
}

.rag-wf-np-scroll {
  flex: 1 1 auto;
  min-height: 0;
  overflow-x: hidden;
  overflow-y: auto;
  overscroll-behavior: contain;
  padding: 8px 10px 12px;
}

.rag-wf-np-group-title {
  margin: 10px 0 6px;
  font-size: 12px;
  color: #9ca3af;
  font-weight: 500;
}

.rag-wf-np-item {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  width: 100%;
  padding: 10px;
  border: none;
  border-radius: 10px;
  background: transparent;
  cursor: pointer;
  text-align: left;
}

.rag-wf-np-item:hover {
  background: #f8fafc;
}

.rag-wf-np-icon {
  width: 34px;
  height: 34px;
  border-radius: 10px;
  background: #f3f4f6;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}

.rag-wf-np-badge {
  font-size: 11px;
  font-weight: 700;
  color: #2563eb;
}

.rag-wf-np-name {
  font-size: 13px;
  color: #111827;
  font-weight: 600;
  font-family: ui-monospace, monospace;
  word-break: break-all;
}
</style>
