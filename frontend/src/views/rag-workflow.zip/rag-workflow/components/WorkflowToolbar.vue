<script setup lang="ts">
import { Icon } from '@iconify/vue';

const emit = defineEmits<{
  'open-picker': [anchor: HTMLElement | null];
  'fit-view': [];
  'reset-view': [];
  'hotkeys': [];
}>();
</script>

<template>
  <aside class="rag-wf-sidebar">
    <ElTooltip content="添加节点" placement="right">
      <button type="button" class="rag-wf-tool-btn" @click="(e: MouseEvent) => emit('open-picker', e.currentTarget as HTMLElement)">
        <Icon icon="mdi:plus" class="rag-wf-tool-ico" />
      </button>
    </ElTooltip>
    <ElTooltip content="适配视图" placement="right">
      <button type="button" class="rag-wf-tool-btn" @click="emit('fit-view')">
        <Icon icon="mdi:fit-to-screen-outline" class="rag-wf-tool-ico" />
      </button>
    </ElTooltip>
    <ElTooltip content="重置视图（1:1）" placement="right">
      <button type="button" class="rag-wf-tool-btn" @click="emit('reset-view')">
        <Icon icon="mdi:restore" class="rag-wf-tool-ico" />
      </button>
    </ElTooltip>
    <ElDropdown trigger="click" @command="(c: string) => (c === 'keys' ? emit('hotkeys') : null)">
      <button type="button" class="rag-wf-tool-btn">
        <Icon icon="mdi:dots-horizontal" class="rag-wf-tool-ico" />
      </button>
      <template #dropdown>
        <ElDropdownMenu>
          <ElDropdownItem command="keys">快捷键说明</ElDropdownItem>
        </ElDropdownMenu>
      </template>
    </ElDropdown>
  </aside>
</template>
