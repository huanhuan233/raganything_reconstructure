<script setup lang="ts">
import { Background } from '@vue-flow/background';
import type { Connection, Edge, Node, ViewportTransform, VueFlowStore } from '@vue-flow/core';
import { VueFlow } from '@vue-flow/core';
import '@vue-flow/core/dist/style.css';
const nodes = defineModel<Node[]>('nodes', { required: true });
const edges = defineModel<Edge[]>('edges', { required: true });

const emit = defineEmits<{
  init: [store: VueFlowStore];
  viewportChange: [vp: ViewportTransform];
  nodeClick: [node: Node];
  paneClick: [];
  connect: [c: Connection];
  structureChange: [];
}>();

function onInit(store: VueFlowStore) {
  emit('init', store);
}

function onViewportChange(vp: ViewportTransform) {
  emit('viewportChange', vp);
}
</script>

<template>
  <div class="rag-wf-flow-inner">
    <VueFlow
      v-model:nodes="nodes"
      v-model:edges="edges"
      class="rag-wf-vue-flow"
      :default-zoom="1"
      :min-zoom="0.4"
      :max-zoom="1.8"
      :nodes-draggable="true"
      :nodes-connectable="true"
      :elements-selectable="true"
      :delete-key-code="true"
      snap-to-grid
      :snap-grid="[14, 14]"
      @init="onInit"
      @viewport-change="onViewportChange"
      @node-click="(e: any) => emit('nodeClick', e.node as Node)"
      @pane-click="emit('paneClick')"
      @connect="c => emit('connect', c)"
      @nodes-change="emit('structureChange')"
      @edges-change="emit('structureChange')"
    >
      <Background :gap="14" variant="dots" pattern-color="#c5cad3" />
    </VueFlow>
    <div v-if="!nodes.length" class="rag-wf-empty-hint">
      点击左侧 <strong>+</strong> 打开节点库，或从列表中选择节点类型添加到画布
    </div>
  </div>
</template>

<style scoped lang="scss">
.rag-wf-flow-inner {
  position: absolute;
  inset: 0;
}

.rag-wf-vue-flow {
  width: 100%;
  height: 100%;
  background: #f3f4f6;
}

.rag-wf-empty-hint {
  position: absolute;
  left: 50%;
  top: 42%;
  transform: translate(-50%, -50%);
  font-size: 13px;
  color: #9ca3af;
  pointer-events: none;
  z-index: 2;
  text-align: center;
  max-width: 320px;
  line-height: 1.5;
}

.rag-wf-flow-inner :deep(.vue-flow) {
  width: 100%;
  height: 100%;
}

.rag-wf-flow-inner :deep(.vue-flow__node-default) {
  border-radius: 10px;
  border: 2px solid #e5e7eb;
  padding: 10px 14px;
  font-size: 13px;
  font-family: Menlo, Monaco, Consolas, 'Courier New', monospace;
  background: #fff;
  box-shadow: 0 1px 8px rgb(15 23 42 / 6%);
  transition:
    border-color 0.15s,
    box-shadow 0.15s;
}

.rag-wf-flow-inner :deep(.vue-flow__node-default:hover) {
  border-color: #cbd5e1;
}

.rag-wf-flow-inner :deep(.vue-flow__node-default.selected) {
  border-color: #2563eb;
  box-shadow: 0 2px 12px rgb(37 99 235 / 18%);
}

.rag-wf-flow-inner :deep(.vue-flow__handle) {
  width: 8px;
  height: 8px;
  border: 2px solid #94a3b8;
  background: #fff;
}

.rag-wf-flow-inner :deep(.vue-flow__handle-left) {
  left: -5px;
}

.rag-wf-flow-inner :deep(.vue-flow__handle-right) {
  right: -5px;
}

.rag-wf-flow-inner :deep(.vue-flow__connectionlinepath) {
  stroke: #2563eb;
  stroke-width: 2px;
}

.rag-wf-flow-inner :deep(.vue-flow__edge-path) {
  stroke: #94a3b8;
}

.rag-wf-flow-inner :deep(.vue-flow__edge.selected .vue-flow__edge-path) {
  stroke: #2563eb;
}
</style>
