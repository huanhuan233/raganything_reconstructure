<script setup lang="ts">
import type { Node } from '@vue-flow/core';
import type { RagFlowNodeData, RagNodeConfigField, RagNodeMetadata } from '@/types/ragWorkflow';

defineProps<{
  selectedNode: Node | null;
  selectedNodeMeta: RagNodeMetadata | null;
  hasConfigSchema: boolean;
  localSchemaConfig: Record<string, unknown>;
}>();

const labelDraft = defineModel<string>('labelDraft', { required: true });
const configDraft = defineModel<string>('configDraft', { required: true });

const emit = defineEmits<{
  'patch-field': [name: string, value: unknown];
  'apply-json-config': [];
}>();

function schemaStrValue(f: RagNodeConfigField, local: Record<string, unknown>): string {
  const v = local[f.name];
  if (v === undefined || v === null) return '';
  return String(v);
}

function schemaOptions(f: RagNodeConfigField): string[] {
  return (f.options ?? []).map(o => String(o));
}
</script>

<template>
  <div class="rag-wf-config rag-wf-config-drawer-root">
    <div class="rag-wf-config-head">
      <span class="rag-wf-config-title">{{ selectedNode ? selectedNode.data?.label || '节点' : '节点' }}</span>
    </div>
    <div class="rag-wf-config-body">
      <template v-if="selectedNode">
        <div class="rag-wf-field">
          <div class="rag-wf-field-label">node_type</div>
          <ElInput :model-value="(selectedNode.data as RagFlowNodeData).nodeType" size="small" readonly />
        </div>
        <div class="rag-wf-field">
          <div class="rag-wf-field-label">node_id</div>
          <ElInput :model-value="String(selectedNode.id)" size="small" readonly class="font-mono" />
        </div>
        <div class="rag-wf-field">
          <div class="rag-wf-field-label">label</div>
          <ElInput v-model="labelDraft" size="small" placeholder="显示名称" />
        </div>

        <template v-if="hasConfigSchema && selectedNodeMeta">
          <div class="rag-wf-field">
            <div class="rag-wf-field-label">config</div>
            <ElForm label-position="top" size="small" class="rag-wf-schema-form" @submit.prevent>
              <template v-for="f in selectedNodeMeta.config_fields" :key="f.name">
                <ElFormItem :required="f.required">
                  <template #label>
                    <span>{{ f.label }}</span>
                    <span v-if="f.description" class="rag-wf-label-tip" :title="f.description"> ⓘ</span>
                  </template>
                  <div v-if="f.description" class="rag-wf-hint">{{ f.description }}</div>
                  <ElInput
                    v-if="f.type === 'string' || f.type === 'path'"
                    size="small"
                    :placeholder="f.placeholder ?? undefined"
                    :model-value="schemaStrValue(f, localSchemaConfig)"
                    @update:model-value="v => emit('patch-field', f.name, v)"
                  />
                  <ElInput
                    v-else-if="f.type === 'number'"
                    size="small"
                    :placeholder="f.placeholder ?? undefined"
                    :model-value="schemaStrValue(f, localSchemaConfig)"
                    @update:model-value="
                      v => emit('patch-field', f.name, v === '' || v === undefined ? undefined : Number(v))
                    "
                  />
                  <ElSwitch
                    v-else-if="f.type === 'boolean'"
                    :model-value="Boolean(localSchemaConfig[f.name])"
                    @update:model-value="v => emit('patch-field', f.name, v)"
                  />
                  <ElSelect
                    v-else-if="f.type === 'select'"
                    size="small"
                    class="rag-wf-select-full"
                    :placeholder="f.placeholder ?? '选择'"
                    :model-value="localSchemaConfig[f.name] as string | undefined"
                    clearable
                    @update:model-value="v => emit('patch-field', f.name, v ?? undefined)"
                  >
                    <ElOption v-for="opt in schemaOptions(f)" :key="opt" :label="opt" :value="opt" />
                  </ElSelect>
                  <ElInput
                    v-else-if="f.type === 'json'"
                    type="textarea"
                    :autosize="{ minRows: 3, maxRows: 10 }"
                    class="font-mono"
                    spellcheck="false"
                    :placeholder="f.placeholder ?? '{}'"
                    :model-value="schemaStrValue(f, localSchemaConfig)"
                    @update:model-value="v => emit('patch-field', f.name, v)"
                  />
                  <ElInput
                    v-else
                    size="small"
                    :placeholder="f.placeholder ?? undefined"
                    :model-value="schemaStrValue(f, localSchemaConfig)"
                    @update:model-value="v => emit('patch-field', f.name, v)"
                  />
                </ElFormItem>
              </template>
            </ElForm>
          </div>
          <ElCollapse class="rag-wf-raw-json">
            <ElCollapseItem title="查看原始 JSON（config）" name="raw">
              <ElInput
                v-model="configDraft"
                type="textarea"
                :autosize="{ minRows: 6, maxRows: 14 }"
                class="font-mono"
                spellcheck="false"
              />
              <ElButton class="mt-8px" size="small" type="primary" @click="emit('apply-json-config')"
                >从 JSON 同步到表单与节点</ElButton
              >
            </ElCollapseItem>
          </ElCollapse>
        </template>
        <template v-else>
          <div class="rag-wf-field">
            <div class="rag-wf-field-label">config（JSON）</div>
            <ElInput v-model="configDraft" type="textarea" :autosize="{ minRows: 10, maxRows: 18 }" class="font-mono" spellcheck="false" />
            <ElButton class="mt-8px" size="small" type="primary" @click="emit('apply-json-config')">立即同步 config</ElButton>
          </div>
        </template>
      </template>
    </div>
  </div>
</template>
